// BrightPages app.js — client-side features: data, filtering, modal, pagination, forms and persistence.
(function () {
  // Sample dataset
  const DATA = [
    {id:1, title:"The Art of Simplicity", author:"Jane Rivers", category:"Design", desc:"A short guide to elegant interfaces."},
    {id:2, title:"Node for Beginners", author:"A. Kumar", category:"Technology", desc:"Intro to backend javascript."},
    {id:3, title:"Fictional Maps", author:"L. Green", category:"Fiction", desc:"A modern fantasy novel."},
    {id:4, title:"Practical CSS", author:"M. Patel", category:"Design", desc:"Practical tips and layout patterns."},
    {id:5, title:"Understanding AI", author:"Dr. Chen", category:"Technology", desc:"A friendly explanation of ML concepts."},
    {id:6, title:"History Unfolded", author:"S. Roy", category:"Non-fiction", desc:"Narratives from world history."},
    {id:7, title:"Design Patterns", author:"E. Morris", category:"Technology", desc:"Software design patterns explained."},
    {id:8, title:"Short Stories", author:"K. Das", category:"Fiction", desc:"A collection of modern short stories."}
  ];

  // Pagination & UI refs
  const PAGE_SIZE = 4;
  let page = 1;
  const cardsEl = document.getElementById('cards');
  const searchEl = document.getElementById('search');
  const categoryEl = document.getElementById('category');
  const prevBtn = document.getElementById('prevPage');
  const nextBtn = document.getElementById('nextPage');
  const pageInfo = document.getElementById('pageInfo');

  // Modal
  const modal = document.getElementById('modal');
  const modalClose = document.getElementById('modalClose');
  const modalTitle = document.getElementById('modalTitle');
  const modalBody = document.getElementById('modalBody');

  function render() {
    const query = (searchEl.value || '').toLowerCase().trim();
    const cat = categoryEl.value;
    const filtered = DATA.filter(item => {
      const matchesQuery = item.title.toLowerCase().includes(query) || item.author.toLowerCase().includes(query);
      const matchesCat = (cat === 'all') || (item.category === cat);
      return matchesQuery && matchesCat;
    });

    const total = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
    if (page > total) page = total;
    const start = (page - 1) * PAGE_SIZE;
    const pageItems = filtered.slice(start, start + PAGE_SIZE);

    cardsEl.innerHTML = '';
    pageItems.forEach(item => {
      const el = document.createElement('article');
      el.className = 'card';
      el.setAttribute('role','listitem');
      el.innerHTML = `
        <div><strong>${escapeHtml(item.title)}</strong></div>
        <div class="meta">${escapeHtml(item.author)} • ${escapeHtml(item.category)}</div>
        <p>${escapeHtml(item.desc)}</p>
        <div class="cta">
          <button data-id="${item.id}" class="details">Details</button>
        </div>
      `;
      cardsEl.appendChild(el);
    });

    pageInfo.textContent = `Page ${page} / ${total}`;
    prevBtn.disabled = page <= 1;
    nextBtn.disabled = page >= total;
  }

  // Escape helper
  function escapeHtml(s){ return String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

  // Events
  searchEl.addEventListener('input', () => { page = 1; render(); });
  categoryEl.addEventListener('change', () => { page = 1; render(); });
  prevBtn.addEventListener('click', () => { page = Math.max(1, page - 1); render(); });
  nextBtn.addEventListener('click', () => { page += 1; render(); });

  // Delegate details click
  cardsEl.addEventListener('click', (e) => {
    if (e.target.matches('button.details')) {
      const id = Number(e.target.dataset.id);
      const item = DATA.find(x => x.id === id);
      if (item) openModal(item.title, `<p><strong>Author:</strong> ${escapeHtml(item.author)}</p><p>${escapeHtml(item.desc)}</p>`);
    }
  });

  // Modal functions
  function openModal(title, html){
    modalTitle.textContent = title;
    modalBody.innerHTML = html;
    modal.setAttribute('aria-hidden','false');
  }
  function closeModal(){ modal.setAttribute('aria-hidden','true'); modalBody.innerHTML = ''; }

  modalClose.addEventListener('click', closeModal);
  modal.addEventListener('click', (e) => { if (e.target === modal) closeModal(); });

  // Theme toggle with persistence
  const themeToggle = document.getElementById('themeToggle');
  const root = document.documentElement;
  const saved = localStorage.getItem('bp_theme');
  if (saved) root.setAttribute('data-theme', saved);
  themeToggle.addEventListener('click', () => {
    const current = root.getAttribute('data-theme') === 'dark' ? 'light' : 'dark';
    root.setAttribute('data-theme', current);
    localStorage.setItem('bp_theme', current);
  });

  // Menu toggle for small screens
  const menuToggle = document.getElementById('menuToggle');
  const menu = document.getElementById('menu');
  menuToggle.addEventListener('click', () => {
    menu.style.display = menu.style.display === 'flex' ? '' : 'flex';
  });

  // Search open focus
  document.getElementById('searchOpen').addEventListener('click', () => { searchEl.focus(); });

  // Jump to library
  document.getElementById('openLibrary').addEventListener('click', () => {
    document.getElementById('library').scrollIntoView({behavior:'smooth'});
  });

  // Contact form handling + save draft
  const form = document.getElementById('contactForm');
  const result = document.getElementById('contactResult');
  const saveDraft = document.getElementById('saveDraft');

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    const data = new FormData(form);
    result.textContent = `Thanks ${data.get('name')} — message saved locally (demo).`;
    form.reset();
    localStorage.removeItem('bp_draft');
  });

  saveDraft.addEventListener('click', () => {
    const data = new FormData(form);
    const obj = {name:data.get('name')||'', email:data.get('email')||'', message:data.get('message')||''};
    localStorage.setItem('bp_draft', JSON.stringify(obj));
    result.textContent = 'Draft saved locally.';
  });

  // Load draft if present
  (function loadDraft() {
    const raw = localStorage.getItem('bp_draft');
    if (!raw) return;
    try {
      const d = JSON.parse(raw);
      form.elements.name.value = d.name || '';
      form.elements.email.value = d.email || '';
      form.elements.message.value = d.message || '';
      result.textContent = 'Loaded saved draft.';
    } catch(e){}
  })();

  // Initial render
  render();

  // Small utility for accessibility: navigate active menu on hash change
  window.addEventListener('hashchange', () => {
    const hash = location.hash || '#home';
    document.querySelectorAll('.menu a').forEach(a => a.classList.toggle('active', a.getAttribute('href') === hash));
  });

})();