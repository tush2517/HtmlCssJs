# BrightPages

BrightPages is an advanced demo front-end project built with plain HTML, CSS, and JavaScript.

Features:
- Responsive layout with a sticky nav
- Light / Dark theme with persistence
- Client-side searchable/paginated library (sample data)
- Accessible modal for details
- Contact form with save-draft (localStorage)
- Small assets included (SVG logo + illustration)

How to use:
1. Unzip the archive.
2. Open `index.html` in a browser.
3. Browse the Library, try search/filter, open Details, and test the contact draft saving.

Files:
- `index.html`
- `assets/css/styles.css`
- `assets/js/app.js`
- `assets/logo.svg`, `assets/illustration.svg`
- `README.md`